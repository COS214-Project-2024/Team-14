var searchData=
[
  ['findcomponent_105',['findComponent',['../classCity.html#ac84bf70abdb7b505e0c5ceee0a308f76',1,'City::findComponent()'],['../classCityComponent.html#a9e31dda1f35a29b90497ef16cb52b24b',1,'CityComponent::findComponent()'],['../classDistrict.html#a8336720f00a6c0eaa8790e7e3f1547ad',1,'District::findComponent()'],['../classNeighborhood.html#a574458beb6be3b90f66c6b4f8067e578',1,'Neighborhood::findComponent()']]],
  ['findorcreatedistrict_106',['findOrCreateDistrict',['../classCity.html#aa152d0d49cd1f7736da6bc684b06ee9a',1,'City']]],
  ['findorcreateneighborhood_107',['findOrCreateNeighborhood',['../classDistrict.html#a53b86971dc7d56d1872888afd154bec6',1,'District']]],
  ['floorarea_108',['floorArea',['../classBuilding.html#af0fec8822ccfdbc051c5da700ac0a321',1,'Building']]],
  ['fuelefficiency_109',['fuelEfficiency',['../classModernTransport.html#a932f9279e86af4a09f47bea8964839e3',1,'ModernTransport']]],
  ['fuelusage_110',['fuelUsage',['../classLegacyTransportSystem.html#a7d1557857095c79b5c48e505dccd5c38',1,'LegacyTransportSystem']]]
];
