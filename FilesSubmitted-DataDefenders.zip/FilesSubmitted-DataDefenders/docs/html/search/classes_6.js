var searchData=
[
  ['healthdepartment_405',['HealthDepartment',['../classHealthDepartment.html',1,'']]]
];
