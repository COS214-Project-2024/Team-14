var searchData=
[
  ['demostrateprototypepattern_80',['demostratePrototypePattern',['../main_8cpp.html#a84baf487fe0bebf8de425799d3e53be4',1,'main.cpp']]],
  ['densityimpact_81',['densityImpact',['../classCitizenSatisfaction.html#a6bae227b71d864149cde8b103f2f1838',1,'CitizenSatisfaction']]],
  ['departments_82',['departments',['../classCompositeGovDepartment.html#af637e0d4c42f2ce4753049a59a546b3a',1,'CompositeGovDepartment']]],
  ['description_83',['description',['../classPublicTransit.html#a5dfc270e85c7c83588fcc60c2b1c027f',1,'PublicTransit::description()'],['../classRoadNetwork.html#a436e22be1422afe77b6fbbd083077c05',1,'RoadNetwork::description()'],['../classUtilityNetwork.html#ac4d3bea4f2418d988a486185b47fbddb',1,'UtilityNetwork::description()']]],
  ['destroyinstance_84',['destroyInstance',['../classCityResourceDistribution.html#a48d38ab51e63e16b9fb4f69be22f6ecd',1,'CityResourceDistribution']]],
  ['detach_85',['detach',['../classCityStats.html#a537b2adf5f37f973c170b9d6d069a64b',1,'CityStats']]],
  ['display_86',['display',['../classPopulationGrowth.html#a4ae244e932abb0bca544185085a18b37',1,'PopulationGrowth::display()'],['../classResourceConsumption.html#a90ac12784022dc32f4ca1dc1621d05f0',1,'ResourceConsumption::display()'],['../classEconomicGrowth.html#a36888f19bfacbe6da8033cdf4862930a',1,'EconomicGrowth::display()'],['../classCityObserver.html#a57c5edef81e7d2921296906d3c819983',1,'CityObserver::display()'],['../classCitizenSatisfaction.html#a7305e4697209ae05221e882c8cdeaf97',1,'CitizenSatisfaction::display()']]],
  ['displayinfo_87',['displayInfo',['../classInfrastructure.html#a619f1a16f2217af3fdec9282240cee37',1,'Infrastructure::displayInfo()'],['../classPublicTransit.html#aeaaae32f76ad9b4b5cfeee5bf1c77453',1,'PublicTransit::displayInfo()'],['../classRoadNetwork.html#a50c519ccc37ad09f86db3c63aea63199',1,'RoadNetwork::displayInfo()'],['../classUtilityNetwork.html#aa9ee504ba1dce7691f68be54555888b6',1,'UtilityNetwork::displayInfo()']]],
  ['distributecapital_88',['distributeCapital',['../classCompositeGovDepartment.html#ab1e087e347b399b729f7368192ad0f56',1,'CompositeGovDepartment']]],
  ['distributeresources_89',['distributeResources',['../classCityResourceDistribution.html#ae39b9f27b6ae978e09b206bde6aedef9',1,'CityResourceDistribution::distributeResources()'],['../classResourceDistributor.html#aa7e9ddac1d1d7eef904ff2830dc83530',1,'ResourceDistributor::distributeResources()']]],
  ['district_90',['District',['../classDistrict.html',1,'District'],['../classDistrict.html#a213616a6e27b20e8c5317caa76cf1d8f',1,'District::District()']]],
  ['district_2eh_91',['District.h',['../District_8h.html',1,'']]],
  ['districts_92',['districts',['../classCity.html#a221a91d575a67bf8e14c941dc408ac89',1,'City']]]
];
