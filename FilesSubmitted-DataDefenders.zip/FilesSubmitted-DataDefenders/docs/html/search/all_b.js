var searchData=
[
  ['name_205',['name',['../classBuilding.html#a6e62ddc243a1f5b900c34c797bff3569',1,'Building::name()'],['../classCity.html#afea8cd8800a8600fa54af37ac05bf177',1,'City::name()'],['../classDistrict.html#a69e54ebd928bd825fc013bdc9b6aec0a',1,'District::name()'],['../classNeighborhood.html#a352223db43fafd575f09825e41a62a03',1,'Neighborhood::name()']]],
  ['needsresource_206',['needsResource',['../classBuilding.html#a544f205b5e64e9e4510a66dec4b737a1',1,'Building::needsResource()'],['../classResourceConsumer.html#a7d929f4b5c7c16d9a342ed88572a43d7',1,'ResourceConsumer::needsResource()']]],
  ['neighborhood_207',['Neighborhood',['../classNeighborhood.html',1,'Neighborhood'],['../classNeighborhood.html#a6f3ca0b192bd9b36f5b550a8cdaf0c2a',1,'Neighborhood::Neighborhood()']]],
  ['neighborhood_2eh_208',['Neighborhood.h',['../Neighborhood_8h.html',1,'']]],
  ['neighborhoods_209',['neighborhoods',['../classDistrict.html#a06db0aa073d620d58f0b38cd84a6e254',1,'District']]],
  ['notify_210',['notify',['../classCityStats.html#a7c90a886d41a1501766794ab333217c8',1,'CityStats']]]
];
