var searchData=
[
  ['observers_211',['observers',['../classCityStats.html#a5b11861c257ea3c7c879f91f63c68fa7',1,'CityStats']]],
  ['oldcapacity_212',['oldCapacity',['../classLegacyTransportSystem.html#aa145f317809f16f84e59561923f5dfec',1,'LegacyTransportSystem']]],
  ['operateoldtransport_213',['operateOldTransport',['../classLegacyTransportSystem.html#a80565052678c4e73fac2fe7f1d26ccc7',1,'LegacyTransportSystem']]],
  ['operational_214',['Operational',['../classOperational.html',1,'']]],
  ['operational_215',['operational',['../classModernTransport.html#a43083c518cdfbfeec4917ea6aa3e0fa5',1,'ModernTransport']]],
  ['operational_2eh_216',['Operational.h',['../Operational_8h.html',1,'']]],
  ['operationmoderntransport_217',['operationModernTransport',['../classModernTransport.html#a420fe1a80ad59e2cbf149106138302d4',1,'ModernTransport::operationModernTransport()'],['../classTransportSystemAdapter.html#a7fa6f1a8cf4fdd2183158b83cb777548',1,'TransportSystemAdapter::operationModernTransport()']]],
  ['operator_3d_218',['operator=',['../classCitizenPrototype.html#a77be5404a60748181d1233991121dae1',1,'CitizenPrototype::operator=()'],['../classCity.html#a02fa7082eb54c3395d18aa06455823a5',1,'City::operator=()'],['../classCityResourceDistribution.html#ab6a0ee81d3b48c7d5bea268b040effe8',1,'CityResourceDistribution::operator=()']]],
  ['overallsatisfaction_219',['overallSatisfaction',['../classCitizenSatisfaction.html#a5e2fbbc10d5596447a34174b5538517e',1,'CitizenSatisfaction']]]
];
